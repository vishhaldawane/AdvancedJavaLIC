package BeginCustomTag.ifElseTagPackage;

import java.io.IOException;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

/** The condition part of an if tag.	*/

public class IfConditionTag90 extends BodyTagSupport
	{	IfTag90 parent = null;
		public int doStartTag() throws JspTagException
			{	parent =	(IfTag90)findAncestorWithClass(this, IfTag90.class);
				if (parent == null)
					{	throw new JspTagException("condition not inside if");	}
				System.out.println("Start of condition");
				return(this.EVAL_BODY_TAG);
			}

		public int doAfterBody()
			{	String bodyString = getBodyContent().getString();
				System.out.println("After of condition");
				if (bodyString.trim().equalsIgnoreCase("true"))
					{	parent.setCondition(true);	}
				else
					{	parent.setCondition(false);	}

				return(SKIP_BODY);
			}
	}
