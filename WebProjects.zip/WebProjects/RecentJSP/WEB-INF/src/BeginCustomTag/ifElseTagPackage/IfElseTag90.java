package BeginCustomTag.ifElseTagPackage;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;

/** The else part of an if tag.	*/
public class IfElseTag90 extends BodyTagSupport
	{	
		public int doStartTag() throws JspTagException
			{	IfTag90 parent = (IfTag90)findAncestorWithClass(this, IfTag90.class);
				System.out.println("Start of else");
				if (parent == null)
					{	throw new JspTagException("else not inside if");	}
				else if (!parent.hasCondition())
					{	String warning = "condition tag must come before else tag";
						throw new JspTagException(warning);
					}
				return(EVAL_BODY_TAG);
			}
	
		public int doAfterBody()
			{	IfTag90 parent = (IfTag90)findAncestorWithClass(this, IfTag90.class);
				System.out.println("After of else"+parent.getCondition());
				if (!parent.getCondition())
					{	try {	BodyContent body = getBodyContent();
								JspWriter out = body.getEnclosingWriter();
								out.print(body.getString());
							}
						catch(IOException ioe)
							{	System.out.println("Error in IfElseTag: " + ioe);	}
					}
				return(this.SKIP_BODY);
			}
	}