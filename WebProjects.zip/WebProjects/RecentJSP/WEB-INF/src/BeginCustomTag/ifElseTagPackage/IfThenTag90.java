package BeginCustomTag.ifElseTagPackage;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;

/** The then part of an if tag.	*/

public class IfThenTag90 extends BodyTagSupport
	{	
		public int doStartTag() throws JspTagException
			{	IfTag90 parent = (IfTag90)findAncestorWithClass(this, IfTag90.class);
				System.out.println("Start of then");
				if (parent == null)
					{	throw new JspTagException("then not inside if");	}
				else if (!parent.hasCondition())
						{	String warning = "condition tag must come before then tag";
							throw new JspTagException(warning);
						}
				return(EVAL_BODY_TAG);
			}
	
		public int doAfterBody()
			{	IfTag90 parent = (IfTag90)findAncestorWithClass(this, IfTag90.class);
				System.out.println("After of then"+parent.getCondition());
				if (parent.getCondition())
					{	try {	BodyContent body = getBodyContent();
								JspWriter out = body.getEnclosingWriter();
								out.print(body.getString());
							}
						catch(IOException ioe)
							{	System.out.println("Error in IfThenTag: " + ioe);	}
					}
				return(SKIP_BODY);
			}
	}