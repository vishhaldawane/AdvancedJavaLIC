package BeginCustomTag;

import java.io.IOException;

import javax.servlet.ServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class Convert31 extends TagSupport 
	{	float rs;
		public int doStartTag() throws JspException
			{	try {	JspWriter out = pageContext.getOut();
						ServletRequest req = this.pageContext.getRequest();
						
						float doll = rs * 46.10f;
						req.setAttribute("Convert", new Float(doll));
						out.print("Pragati Software Pvt. Ltd.");
					}
				catch (IOException ioe)
					{	//System.out.println("Error in ExampleTag: "+ioe);
						throw new JspException("Exception in ExampleTag10", ioe);
					}
				return (SKIP_BODY);
			}
		public void setRs(Float f)
			{ rs = f.floatValue();	 }
	}
