package BeginCustomTag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

public class RepeatTag60 extends BodyTagSupport
	{	private int initVal=1;
		private int finalVal=10;
		private int stepVal = 1;
		
		public void setIVal(String iVal)
			{	try {	initVal = Integer.parseInt(iVal);	}
				catch(NumberFormatException nfe)
					{	initVal = 1;	}
			}
		
		public void setFVal(String fiVal)
			{	try {	finalVal = Integer.parseInt(fiVal);	}
				catch(NumberFormatException nfe)
					{	finalVal = 10;	}
			}

		public void setStep(String step)
			{	try {	stepVal = Integer.parseInt(step);	}
				catch(NumberFormatException nfe)
					{	stepVal = 1;	}
			}
		
		public int doAfterBody()
			{	if (stepVal>0)
					if (initVal<=finalVal)
						{	BodyContent body = getBodyContent();
							try {	JspWriter out = body.getEnclosingWriter();
									out.println("<BR>("+initVal+")"+body.getString());
									body.clearBody(); // Clear for next evaluation
								}
							catch(IOException ioe)
								{	System.out.println("Error in RepeatTag: " + ioe);	}
				
							initVal+=stepVal;
							return(this.EVAL_BODY_AGAIN);
						}
					else
						{	return(SKIP_BODY);	}
			else if (stepVal<0)
				if (finalVal<=initVal)
					{	BodyContent body = getBodyContent();
						try {	JspWriter out = body.getEnclosingWriter();
								out.println("<BR>("+initVal+")"+body.getString());
								body.clearBody(); // Clear for next evaluation
							}
						catch(IOException ioe)
							{	System.out.println("Error in RepeatTag: " + ioe);	}
			
						initVal+=stepVal;
						return(this.EVAL_BODY_AGAIN);
					}
				else
					{	return(SKIP_BODY);	}
			else
				return(SKIP_BODY);
			}
	}