package BeginCustomTag;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;

/** A tag that repeats the body the specified
 	* number of times.
*/
public class RepeatTag50 extends BodyTagSupport
	{	private int reps;
		public void setTimes(String repeats)
			{	try {	reps = Integer.parseInt(repeats);}
				catch(NumberFormatException nfe)
					{	reps = 1;	}
			}
		
		public int doAfterBody()
			{	if (reps-- >= 1)
					{	BodyContent body = getBodyContent();
						try {	JspWriter out = body.getEnclosingWriter();
								out.println(body.getString());
								body.clearBody(); // Clear for next evaluation
							}
						catch(IOException ioe)
							{	System.out.println("Error in RepeatTag: " + ioe);	}
						
						return(this.EVAL_BODY_AGAIN);
					}
				else {	return(SKIP_BODY);	}
			
			}
		
	}
