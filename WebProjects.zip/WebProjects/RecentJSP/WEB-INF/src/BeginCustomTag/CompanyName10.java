package BeginCustomTag;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;
import java.io.IOException;

public class CompanyName10 extends TagSupport 
	{	public int doStartTag() throws JspException
			{	try {	JspWriter out = pageContext.getOut();
						out.print("Pragati Software Pvt. Ltd.");
					}
				catch (IOException ioe)
					{	//System.out.println("Error in ExampleTag: "+ioe);
						throw new JspException("Exception in ExampleTag10", ioe);
					}
				return (SKIP_BODY);
			}
	}
