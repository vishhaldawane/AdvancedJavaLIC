/* compiled from JSP: /JSP/HelloWorld11/JSPDeclarations22.jsp
*
* This code was automatically generated at 2:24:35 PM on Oct 19, 2006
* by weblogic.servlet.jsp.Jsp2Java -- do not edit.
*/

package jsp_servlet._jsp._helloworld11;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

// User imports
import java.util.Date; //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 10]


// built-in init parameters:
// boolean             _verbose -- wants debugging

// Well-known variables:
// JspWriter out                  -- to write to the browser
// HttpServletRequest  request    -- the request object.
// HttpServletResponse response   -- the response object.
// PageContext pageContext        -- the page context for this JSP
// HttpSession session            -- the session object for the client (if any)
// ServletContext application     -- The servlet (application) context
// ServletConfig config           -- The ServletConfig for this JSP
// Object page                    -- the instance of this page's implementation class (i.e., 'this')

/**
* This code was automatically generated at 2:24:35 PM on Oct 19, 2006
* by weblogic.servlet.jsp.Jsp2Java -- do not edit.
*
* Copyright (c) 2006 by BEA Systems, Inc. All Rights Reserved.
*/
public final class __jspdeclarations22
extends
weblogic.servlet.jsp.JspBase
implements weblogic.servlet.jsp.StaleIndicator
{
  
  int hitCount; //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 13]
  Date lastDateOfHit; //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 14]
  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 15]
  public void jspInit() //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 18]
  {	hitCount = 0; //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 19]
    lastDateOfHit = new Date(); //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 20]
    System.out.println("Initialization and enguaging resources.");	 //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 21]
  } //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 22]
  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 23]
  public void jspDestroy() //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 26]
  {	System.out.println("Resources Released.");	} //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 27]
  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 28]
  public String formatDate(Date dt) //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 54]
  {	Calendar cal = Calendar.getInstance(); //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 55]
    cal.setTime(dt); //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 56]
    String td = cal.get(Calendar.DAY_OF_MONTH)+"/"+cal.get(Calendar.MONTH)+"/"+cal.get(Calendar.YEAR); //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 57]
    return td; //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 58]
  } //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 59]
  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 60]
  // StaleIndicator interface
  public boolean _isStale() {
    weblogic.servlet.jsp.StaleChecker sci =(weblogic.servlet.jsp.StaleChecker)(getServletConfig().getServletContext());
    java.io.File f = null;
    long lastModWhenBuilt = 0L;
    if (sci.isResourceStale("/JSP/HelloWorld11/JSPDeclarations22.jsp", 1161247207382L, "8.1.1.0")) return true;
    return false;
  }
  
  public static boolean _staticIsStale(weblogic.servlet.jsp.StaleChecker sci) {
    java.io.File f = null;
    long lastModWhenBuilt = 0L;
    if (sci.isResourceStale("/JSP/HelloWorld11/JSPDeclarations22.jsp", 1161247207382L, "8.1.1.0")) return true;
    return false;
  }
  
  public void jspInit()
  	{	super.jspInit();
  		ServletContext cst cst= new ServletContext();
	  
  	}
  private static void _writeText(ServletResponse rsp, JspWriter out, String block, byte[] blockBytes) throws IOException {
    if (!_WL_ENCODED_BYTES_OK || _hasEncodingChanged(rsp)) {
      out.print(block);
    } else {
      ((weblogic.servlet.jsp.ByteWriter)out).write(blockBytes, block);
    } 
  }
  
  private static boolean _hasEncodingChanged(ServletResponse rsp) {
    String encoding = rsp.getCharacterEncoding();
    if ("ISO-8859-1".equals(encoding)  || "Cp1252".equals(encoding) || "ISO8859_1".equals(encoding) || "ASCII".equals(encoding)) {
      return false;
    }
    if (_WL_ORIGINAL_ENCODING.equals(encoding)) {
      return false;
    }
    return true;
  }
  
  private static boolean _WL_ENCODED_BYTES_OK = true;
  
  private static final String _WL_ORIGINAL_ENCODING = "Cp1252";
  
  private static byte[] _getBytes(String block) {
    try {
      return block.getBytes(_WL_ORIGINAL_ENCODING);
    } catch (java.io.UnsupportedEncodingException u) {
      _WL_ENCODED_BYTES_OK = false;
    }
    return null;
  }
  private final static String _wl_block0 = "<! DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\r\n\r\n\r\n<!-- This is HTML page.  It is passed to browser as a part of html-->\r\n\r\n\r\n\r\n\r\n";
  private final static byte[] _wl_block0Bytes = _getBytes(_wl_block0);
  private final static String _wl_block1 = "<%@ page import = \"java.util.Date\", \"java.util.Calendar\" %>\r\n\r\n\r\n\t";
  private final static byte[] _wl_block1Bytes = _getBytes(_wl_block1);
  private final static String _wl_block2 = "\r\n\r\n\r\n\t";
  private final static byte[] _wl_block2Bytes = _getBytes(_wl_block2);
  private final static String _wl_block3 = "\r\n\r\n\r\n\t";
  private final static byte[] _wl_block3Bytes = _getBytes(_wl_block3);
  private final static String _wl_block4 = "\r\n\r\n\r\n\r\n\r\nServlet Context Information...<BR>\r\n\tServer Information:  ";
  private final static byte[] _wl_block4Bytes = _getBytes(_wl_block4);
  private final static String _wl_block5 = "<BR>\r\n\tMajor Version: ";
  private final static byte[] _wl_block5Bytes = _getBytes(_wl_block5);
  private final static String _wl_block6 = "<BR>\r\n\tMinor Version: ";
  private final static byte[] _wl_block6Bytes = _getBytes(_wl_block6);
  private final static String _wl_block7 = "<BR>\r\n\tServlet Context: ";
  private final static byte[] _wl_block7Bytes = _getBytes(_wl_block7);
  private final static String _wl_block8 = "<BR>\r\n<BR>\r\nServlet Config Information...<BR>\r\n\tServlet Name: ";
  private final static byte[] _wl_block8Bytes = _getBytes(_wl_block8);
  private final static String _wl_block9 = "<BR>\r\n\r\n<BR>\r\nSession Information...<BR>\r\n\tSessin ID: ";
  private final static byte[] _wl_block9Bytes = _getBytes(_wl_block9);
  private final static String _wl_block10 = "<BR>\r\n\tLast time access: ";
  private final static byte[] _wl_block10Bytes = _getBytes(_wl_block10);
  private final static String _wl_block11 = "<BR>\r\n\tCreation time: ";
  private final static byte[] _wl_block11Bytes = _getBytes(_wl_block11);
  private final static String _wl_block12 = "<BR>\r\n\r\n<BR><BR><BR>\r\n\tThis JSP is hit for ";
  private final static byte[] _wl_block12Bytes = _getBytes(_wl_block12);
  private final static String _wl_block13 = " number of times. The last hit is on ";
  private final static byte[] _wl_block13Bytes = _getBytes(_wl_block13);
  private final static String _wl_block14 = "\r\n\r\n\t";
  private final static byte[] _wl_block14Bytes = _getBytes(_wl_block14);
  private final static String _wl_block15 = "\r\n\t\r\n\r\n\t";
  private final static byte[] _wl_block15Bytes = _getBytes(_wl_block15);
  
  
  public void _jspService(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.io.IOException, javax.servlet.ServletException 
  {  
    
    // declare and set well-known variables:
    javax.servlet.ServletConfig config = getServletConfig();
    javax.servlet.ServletContext application = config.getServletContext();
    javax.servlet.jsp.tagext.Tag _activeTag = null;
    // variables for Tag extension protocol
    
    Object page = this;
    javax.servlet.jsp.JspWriter out;
    javax.servlet.jsp.PageContext pageContext =
    javax.servlet.jsp.JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
    
    out = pageContext.getOut();
    JspWriter _originalOut = out;
    
    javax.servlet.http.HttpSession session = request.getSession(true);
    
    
    
    try { // error page try block
      
      response.setContentType("text/html");
      
      _writeText(response, out, _wl_block0, _wl_block0Bytes);
      _writeText(response, out, _wl_block1, _wl_block1Bytes);
      _writeText(response, out, _wl_block2, _wl_block2Bytes);
      _writeText(response, out, _wl_block3, _wl_block3Bytes);
      _writeText(response, out, _wl_block4, _wl_block4Bytes);
      out.print(String.valueOf( application.getServerInfo()));  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 34]
      _writeText(response, out, _wl_block5, _wl_block5Bytes);
      out.print(String.valueOf( application.getMajorVersion()));  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 35]
      _writeText(response, out, _wl_block6, _wl_block6Bytes);
      out.print(String.valueOf( application.getMinorVersion()));  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 36]
      _writeText(response, out, _wl_block7, _wl_block7Bytes);
      out.print(String.valueOf( application.getServletContextName()));  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 37]
      _writeText(response, out, _wl_block8, _wl_block8Bytes);
      out.print(String.valueOf( config.getServletName()));  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 40]
      _writeText(response, out, _wl_block9, _wl_block9Bytes);
      out.print(String.valueOf( session.getId()));  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 44]
      _writeText(response, out, _wl_block10, _wl_block10Bytes);
      out.print(String.valueOf( session.getLastAccessedTime()));  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 45]
      _writeText(response, out, _wl_block11, _wl_block11Bytes);
      out.print(String.valueOf( session.getCreationTime()));  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 46]
      _writeText(response, out, _wl_block12, _wl_block12Bytes);
      out.print(String.valueOf( (++hitCount)));  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 49]
      _writeText(response, out, _wl_block13, _wl_block13Bytes);
      out.print(String.valueOf( formatDate(lastDateOfHit)));  //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 49]
      _writeText(response, out, _wl_block14, _wl_block14Bytes);
      lastDateOfHit = new Date(); //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 51]
      //[ /JSP/HelloWorld11/JSPDeclarations22.jsp; Line: 51]
      _writeText(response, out, _wl_block15, _wl_block15Bytes);
    } catch (Throwable __ee) {
      while (out != null && out != _originalOut) out = pageContext.popBody();
      ((weblogic.servlet.jsp.PageContextImpl)pageContext).handlePageException((Throwable)__ee);
    }
    
    
    //before final close brace...
  }
  
  
}
