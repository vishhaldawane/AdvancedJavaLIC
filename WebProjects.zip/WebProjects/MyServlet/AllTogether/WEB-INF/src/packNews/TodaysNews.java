package packNews;
public class TodaysNews
	{	public static String[] news = new String[5];
		static {
					for(int i=0; i<news.length; i++)
						news[i] = new String("No news today");
				}
		public synchronized static void addNews(String str, int newsHead)
			{	news[newsHead-1] = str;	}
		
		public synchronized static void clearNews(int newsHead)
			{	news[newsHead-1] = "";	}
		
		public synchronized static String readNews(int newsHead)
			{	return news[newsHead-1];	}
	}