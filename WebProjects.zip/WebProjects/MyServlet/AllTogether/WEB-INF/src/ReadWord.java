import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ReadWord extends HttpServlet
	{
	
		protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	arg1.setContentType("application/msword");	// Setting content type.
			    ServletContext context = getServletContext();
			    InputStream is = context.getResourceAsStream("/ShortCut Keys.doc");
			    //InputStream is = context.getResourceAsStream("C:/chandra/webapp06/shortcuts.pdf");
			    int read = 0;
			    byte bytes[] = new byte[1024];
			    OutputStream os = arg1.getOutputStream();
			    while((read = is.read(bytes))!= -1)
			    	{os.write(bytes, 0, read);}
			    os.flush();
			    os.close();	
			}
	
		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}
	
	}
