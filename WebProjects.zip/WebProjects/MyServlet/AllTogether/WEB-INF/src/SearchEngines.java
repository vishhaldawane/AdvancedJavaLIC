import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SearchEngines extends HttpServlet
	{	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	
				try {
				String srchStr = arg0.getParameter("searchstring");
				
				PrintWriter out = arg1.getWriter();
				
				if ((srchStr==null) ||(srchStr.length()==0))
					{	System.out.println("Missing search string.");
						reportProblem(arg1, "Missing Search String.");
						return;
					}
				
				srchStr = arg1.encodeURL(srchStr);
				
				String srchEngine = arg0.getParameter("searchengine");
								
				String url = SearchSpec.getURLforEngine(srchEngine, srchStr);
				if (url != null)
					arg1.sendRedirect(url);
				else
					{	System.out.println("Search engine not found.");
						reportProblem(arg1, "Unrecognized Search Engine.");
					}
				}
				catch(Exception e)
				{
					System.out.println("Error "+e);
					e.printStackTrace();
				}
			}
		private void reportProblem(HttpServletResponse arg1, String msg) throws IOException
			{	arg1.sendError(HttpServletResponse.SC_NOT_FOUND, "<H2>"+msg+"</H2>");}
		
		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	
				//System.out.println(" I am in doPost.");
				doGet(arg0, arg1);
			}	
	}
