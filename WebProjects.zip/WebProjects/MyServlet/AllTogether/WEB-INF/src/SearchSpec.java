
public class SearchSpec
	{	private String name;
		private String baseURL;
		
		
		private static SearchSpec[] commonSpects =
			{	new SearchSpec("google", "http://www.google.com/search?q="),
				new SearchSpec("alltheweb", "http://www.alltheweb.com/search?q="),
				new SearchSpec("yahoo", "http://search.yahoo.com/bin/search?p="),
				new SearchSpec("altavista", "http://www.altavista.com/web/results?q="),
				new SearchSpec("lycos", "http://search.lycos.com/default.asp?query="),
				new SearchSpec("hotbot", "http://hotbot.com/default.asp?query="),
				new SearchSpec("msn", "http://search.msn.com/results.asp?q=")
			};
		
		public SearchSpec(String name, String baseURL)
			{	this.name = name;
				this.baseURL = baseURL;
			}
		
		public static String getURLforEngine(String engineName, String searchString)
			{	String searchURL = null;
				for(int i = 0; i<commonSpects.length; i++)
					{	if ((commonSpects[i].name).equalsIgnoreCase(engineName))
							{	searchURL = commonSpects[i].baseURL+searchString;
								break;
							}
					}
				return searchURL;
			}
	}
