import packNews.TodaysNews;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EditorServlet extends HttpServlet
	{	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	String action = arg0.getParameter("action");
				String news	  = arg0.getParameter("news");
				int newsHead = Integer.parseInt(arg0.getParameter("newsHead"));
				
				if (action.trim().equalsIgnoreCase("add"))
					TodaysNews.addNews(news,newsHead);
				if (action.trim().equalsIgnoreCase("clear"))
					TodaysNews.clearNews(newsHead);
				PrintWriter out = arg1.getWriter();
				out.println("Done");
			}

		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}	
	}
