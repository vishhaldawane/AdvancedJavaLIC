import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletConfig;
import javax.sql.DataSource;

public class JDBC3 extends HttpServlet
	{ Connection con;
	  Statement st;
	  ResultSet rs;
	  DataSource ds;
	  public void init(ServletConfig sc) throws ServletException
		{	super.init();
			try { 	Context ctx = new InitialContext();
					ds = (DataSource) ctx.lookup("ThinJNDI");
				}
			catch (NamingException ne)
				{ new ServletException("Exception in init() of JDBC3", ne);}
		}
	  
	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
		{	arg1.setContentType("text/plain");
			try { 
			con = ds.getConnection();
			st = con.createStatement();
			
			PrintWriter out = arg1.getWriter();
		 	 rs = st.executeQuery("select EMPNO, ENAME from emp");
					while (rs.next())
						{	int no = rs.getInt("EMPNO");
							String str = rs.getString("ENAME");
							System.out.println(no);
							out.println(no+" "+str);
						}
					out.println("The above data is from table.");
					rs.close();
					st.close();
					con.close();
				}
			catch (SQLException sql)
				{	sql.printStackTrace();	}
		}

	protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
		{	doGet(arg0, arg1);	}

	public void destroy()
		{	try {	if (con != null)
						con.close();
				}
			catch(SQLException sql)
				{	}
		}
	}

