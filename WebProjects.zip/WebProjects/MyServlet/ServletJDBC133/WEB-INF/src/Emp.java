
public class Emp
	{

	public Emp()
		{	}

}
