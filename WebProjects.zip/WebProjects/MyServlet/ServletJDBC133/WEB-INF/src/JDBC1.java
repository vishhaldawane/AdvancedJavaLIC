import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class JDBC1 extends HttpServlet
	{ Connection con;
	  Statement st;
	  ResultSet rs;
	  private void process()
		  {	try {
				while (rs.next())
					{	int no = rs.getInt("EMPNO");
						System.out.println(no);
						//out.println(no);
					}
		  		}
			catch (SQLException sql)
				{	sql.printStackTrace();	}
		  }
	  
	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
		{	arg1.setContentType("text/html");
			PrintWriter out = arg1.getWriter();
			try {
					while (rs.next())
						{	int no = rs.getInt("EMPNO");
							String enm = rs.getString("ENAME");
							System.out.println(no);
							out.println(enm+" "+no+"<BR>");
						}
				}
			catch (SQLException sql)
				{	sql.printStackTrace();	}
		
		}

	protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
		{	doGet(arg0, arg1);	}

	public void init() throws ServletException
		{	super.init();
			try { 
				//Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				Class.forName("oracle.jdbc.driver.OracleDriver");
				
				//con = DriverManager.getConnection("jdbc:odbc:javaDSN", "scott", "tiger");
				con = DriverManager.getConnection("jdbc:oracle:thin:@rac940:1521:CHANDRA", "scott", "tiger");
				st = con.createStatement();
				rs = st.executeQuery("select EMPNO, ENAME from emp");
				}
			catch (ClassNotFoundException cfe)
				{}
			catch (SQLException se)
				{}
		}
	public void destroy()
		{	try {	rs.close();
					st.close();
					con.close();
				}
			catch(SQLException sql)
				{	}
		}
	public static void main(String [] argv) throws ClassNotFoundException, SQLException, ServletException
		{ JDBC1 j = new JDBC1();
			j.init();
			j.process();
			j.destroy();
		}
	}
