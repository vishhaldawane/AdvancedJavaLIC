import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class JDBC2 extends HttpServlet
	{	Connection conn;
		public void init()
			{	ServletContext scx = this.getServletContext();
				String driver = scx.getInitParameter("driver");
				String url = scx.getInitParameter("url");
				String username = scx.getInitParameter("username");
				String passwd = scx.getInitParameter("passwd");
				
				try {	//Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
						Class.forName(driver);
						//conn = DriverManager.getConnection("jdbc:odbc:javaDSN", "scott", "tiger");
						conn = DriverManager.getConnection(url, username, passwd);
					}
				catch (ClassNotFoundException e)
					{	e.printStackTrace();	} 
				catch (SQLException e)
					{	e.printStackTrace();	}
			}	
		protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	arg1.setContentType("text/html");
				PrintWriter out = arg1.getWriter();
				String sear = (arg0.getParameter("search")).trim();
				System.out.println(sear);
				int eno;
				String enm;
				float esal;
				try {	PreparedStatement pps = conn.prepareStatement("Select empno, ename, sal from emp where ename like ?");
						pps.setString(1, sear+"%");
						ResultSet rs = pps.executeQuery();
						out.println(ServletUtilities.headWithTitle("Config-Context-JDBC")+
								"<BODY BGCOLOR=\"#FDF5E6\">"+
								"<H1 ALIGN=\"CENTER\">Config-Context-JDBC</H1>"+
								"<TABLE BORDER=1 ALIGN=\"CENTER\""+
								"<TR BGCOLOR=\"#FFAD00\">"+
								"<TH>EmpNo<TH>EmpNm<TH>Sal");
						while (rs.next())
							{	eno=rs.getInt("empno");
								enm=rs.getString("ename");
								esal=rs.getFloat("sal");
								out.println("<TR><TD>"+eno+"<TD>"+enm+"<TD>"+esal);
								//System.out.println(eno+" "+enm+" "+esal);
							}
						out.println("</BODY></HTML>");
						rs.close();
						pps.close();
						
					}
				catch (SQLException e)
					{	e.printStackTrace();	}
			}
				public void destroy()
					{	try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	}
		

		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}		
	}
