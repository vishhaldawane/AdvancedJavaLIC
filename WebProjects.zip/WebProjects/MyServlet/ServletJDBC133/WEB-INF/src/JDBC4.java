import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletConfig;
import javax.sql.DataSource;

class AccessBean
	{	DataSource ds;
	
		public AccessBean(DataSource ds)
			{	this.ds = ds;	}
		
		public AccessBean(String jndi) throws NamingException
			{	Context ctx = new InitialContext();
				ds = (DataSource) ctx.lookup(jndi);	// "ThinJNDI"
			}
		
		public String[][] getList(String qry) throws SQLException
			{	Connection conn = ds.getConnection();
				Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				ResultSet rs = st.executeQuery(qry);
				ResultSetMetaData rsmd = rs.getMetaData();
				
				int noOfCols = rsmd.getColumnCount();
				rs.last();
				int noOfRows = rs.getRow(); 
				rs.beforeFirst();
				String [][]table = new String[noOfRows][noOfCols];
				
				// Column heads
				for(int j=0; j<noOfCols; j++)
					table[0][j] = rsmd.getColumnName(j+1);
				
				// Table Body
				for(int i=0; rs.next(); i++)
					for(int j=0; j<noOfCols; j++)
						table[i][j] = rs.getString(j+1);
				
				rs.close();
				st.close();
				conn.close();
				return table;
			}
	}

public class JDBC4 extends HttpServlet
	{ 	AccessBean ab;
	  	public void init(ServletConfig sc) throws ServletException
			{	super.init();
				
				String jndi = sc.getInitParameter("jndi");	//"ThinJNDI"
				
				try	{	ab = new AccessBean(jndi);	}
				catch (NamingException ne)
					{	throw new ServletException("Exception while creating AccessBean", ne);	}
			}
	 
		protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	arg1.setContentType("text/html");
				PrintWriter out = arg1.getWriter();
				String [][] table = null;
			 	try {  table = ab.getList("select EMPNO, ENAME, sal from emp");	}
			 	catch (SQLException sql)
			 		{	throw new ServletException("Exception in reading table from data base", sql);	}
			 	
	        	out.println("<TABLE BORDER=1 ALIGN=CENTER>");
		        	out.println("<TR BGCOLOR='#FFAD00'>");
					for(int i =0; i<table[0].length; i++)
						out.println("<TH>"+table[0][i]);
				
					for(int i=0; i<table.length; i++)
						{	out.println("<TR>");
							for(int j=0; j<table[i].length; j++)
								out.println("<TD>"+table[i][j]);
						}
				out.println("</TABLE>");
			}

	protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
		{	doGet(arg0, arg1);	}
	}
