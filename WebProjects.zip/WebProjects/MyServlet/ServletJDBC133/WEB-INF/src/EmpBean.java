import java.util.Calendar;

public class EmpBean
	{	int empNo;
		String eName;
		Calendar dateOfBirth;
		
		public EmpBean(int empNo, String eName, Calendar dob)
			{	this.empNo = empNo;
				this.eName = eName;
				this.dateOfBirth = dob;
			}
		
		public String[] listDOB()
			{	String cond = "(to_char(sysdate, 'dd')=to_char(dob, 'dd')) and (to_char(sysdate, 'mm')=to_char(dob, 'mm'))";
				String str = "select eName from EMP where "	+ cond;
				
			}
	}
