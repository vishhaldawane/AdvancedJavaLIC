package packbank;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import packcommon.ServletUtilities;

public class MainPage extends HttpServlet
	{	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	String accounttype = arg0.getParameter("accounttype");
				
				PrintWriter out = arg1.getWriter();
				ServletUtilities.PageHead(arg1, "CurrentServlet");
				out.println("<BODY BGCOLOR=\"#FDF4E6\">" +
						"<H3 ALIGN=\"CENTER\">Bank Servlet</H3><BR>"+
						"<H4 ALIGN=\"CENTER\">XYZ BANK</H4><BR><BR>"+
						"<H5 ALIGN=\"CENTER\">Branch Mumbai</H5>"
						);
				
				RequestDispatcher rd;
				if (accounttype.equalsIgnoreCase("Current"))
					{	rd = arg0.getRequestDispatcher("/current");
						rd.forward(arg0, arg1);
					}
				else
					{	rd = arg0.getRequestDispatcher("/saving");
						rd.include(arg0, arg1);
					}
				out.println("Address: Lok Center <BR> Marol Maroshi Road <BR> Marol <BR> Andheri(E)");
				ServletUtilities.PageFoot(arg1);
			}

		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);}
	}
