package packbank02;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class SavingBankBean
	{	Connection conn;
			
		public SavingBankBean(String driver, String url, String user, String passwd) throws ClassNotFoundException, SQLException
			{	Class.forName(driver);
				//System.out.println(" D:"+driver+" U:"+url+" N:"+user+" P"+passwd);
				conn = DriverManager.getConnection(url, user, passwd);
			}
		public void addNew(String accNm, String accAdd, float accBal) throws SQLException
			{	int newAccNO = getMaxAccNo()+1;	
				String str = "insert into AccountMaster (accNo,accNm, accAdd, accBal) values (?,?,?,?)";
				PreparedStatement pst = conn.prepareCall(str, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
				pst.setInt(1, newAccNO);
				pst.setString(2, accNm);
				pst.setString(3, accAdd);
				pst.setFloat(4, accBal);
				pst.executeUpdate();
				pst.close();
			}
		
		public int getMaxAccNo() throws SQLException
			{	String qre = "Select max(accNo) from AccountMaster";
				Statement st = conn.createStatement();
				int accNo = 0;
				
				ResultSet rs = st.executeQuery(qre);
				if (rs!=null)
					{	rs.next();
						accNo = rs.getInt(1);
					}
				rs.close();
				st.close();
				return accNo;
			}
		
		public String[][] queryTable(String query) throws SQLException
			{	Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);	
				ResultSet rs = st.executeQuery(query);
				ResultSetMetaData rsmd = rs.getMetaData();
				int noOfColumns = rsmd.getColumnCount();
				rs.last();
				int noOfRows = rs.getRow()+1;
				String [][] table = new String[noOfRows][noOfColumns];
				
				rs.beforeFirst();
				
				// Creating Table
				for(int i =0; i<noOfColumns; i++)
					table[0][i] = rsmd.getColumnName(i+1);
				
				for(int i=1; rs.next(); i++)
					for(int j=0; j<noOfColumns; j++)
						table[i][j]=rs.getString(j+1);
				return table;
			}
		
		public void closeAll() throws SQLException
			{	conn.close();	}
		
		public static void main(String [] argv)
			{	String driver = "oracle.jdbc.driver.OracleDriver";
				String url ="jdbc:oracle:thin:@rac940:1521:CHANDRA";
				
				String userName = "scott";
				String passWd = "tiger";
				try {	SavingBankBean sbb = new SavingBankBean(driver, url, userName, passWd);
						//sbb.addNew("MachineM", "Mumbai", 5000f);
						String[][] table = sbb.queryTable("Select * from accountmaster");
						for(int i=0; i<table.length; i++)
							{	for(int j = 0; j<table[i].length; j++)
									System.out.print(table[i][j]+"  ");
								System.out.println();
							}
						sbb.closeAll();
					}
				catch (ClassNotFoundException e)
					{	e.printStackTrace();	}
				catch (SQLException e)
					{	e.printStackTrace();	}
			}
	}
