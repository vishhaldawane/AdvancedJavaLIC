package packwelcome;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WhatsTimeNow3 extends HttpServlet
	{		private void commonFunction(HttpServletRequest arg0, HttpServletResponse arg1)
				throws IOException
				{	PrintWriter out = arg1.getWriter();
					PrintHead3.PageHead(arg1, "World Clock");
					
						out.println("Time India       :"+ZoneWiseTime3.getTimeInZone("India")+"<BR>"+"<BR>");
						out.println("Time USA     	  :"+ZoneWiseTime3.getTimeInZone("usa")+"<BR>"+"<BR>");
						out.println("Time Russia      :"+ZoneWiseTime3.getTimeInZone("Russia")+"<BR>"+"<BR>");
						out.println("Time Japan       :"+ZoneWiseTime3.getTimeInZone("Japan")+"<BR>"+"<BR>");
						out.println("Time Britain	  :"+ZoneWiseTime3.getTimeInZone("Britain")+"<BR>"+"<BR>");
						out.println("Time South Africa:"+ZoneWiseTime3.getTimeInZone("South Africa")+"<BR>");
						
					PrintHead3.PageFoot(arg1);
				}
			protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1)
				throws IOException
				{	commonFunction(arg0, arg1);	}
			protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1)
				throws IOException
				{	commonFunction(arg0, arg1);	}
	}
