package packresponse03;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WriteExcel extends HttpServlet
	{	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	arg1.setContentType("application/vnd.ms-excel");	// Displays underlaying text in excel form
				
				PrintWriter out = arg1.getWriter();
				out.println("\tQ1\tQ2\tQ3\tQ4\tTOTAL");
				out.println("Apples\t28\t35\t45\t56\t=sum(B2:E2)");
				out.println("Mangos\t12\t34\t45\t56\t=sum(B3:E3)");
				out.println("Orange\t56\t67\t78\t89\t=sum(B4:E4)");
			}

		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}	
	}
