import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class GetterRedirection	extends HttpServlet
	{	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	HttpSession sess = arg0.getSession();
				String sessID = sess.getId();
				String attrID = (String) sess.getAttribute("sessionID");
				
				arg1.setContentType("text/html");
				PrintWriter out = arg1.getWriter();
				out.println(ServletUtilities.headWithTitle("Getting Session ID from Redirection")+
						"<BODY ALIGN=\"CENTER\">");
				if (sessID.equalsIgnoreCase(attrID))
					out.println("Matched");
				else
					out.println("Unmatched");
				out.println("</BODY></HTML>");
			}

		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}	
	}

