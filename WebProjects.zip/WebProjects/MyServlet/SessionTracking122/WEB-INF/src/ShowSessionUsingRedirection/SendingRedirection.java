import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SendingRedirection extends HttpServlet
	{	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	String url = "http://localhost:7001/SessionTracking122/getredirect";
				HttpSession sess = arg0.getSession();
				String sessid = sess.getId();
				sess.setAttribute("sessionID", sessid);
				System.out.println("Session ID from Sender : ");
				System.out.println(sessid);
				arg1.sendRedirect(url);
			}

		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}	
	}

