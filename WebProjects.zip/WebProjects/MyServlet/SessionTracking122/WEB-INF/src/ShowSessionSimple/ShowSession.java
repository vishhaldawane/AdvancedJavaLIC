import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ShowSession extends HttpServlet
	{	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	HttpSession sess = arg0.getSession(true);
				Integer accessCount = (Integer) sess.getAttribute("accesscount");
				String sessionHead;
				if (accessCount==null)
					{	accessCount=new Integer(0);
						sessionHead = "Welcome Newcommer";
					}
				else
					{	accessCount=new Integer(accessCount.intValue()+1);
						sessionHead = "Welcome Old user";
					}
				sess.setAttribute("accesscount", accessCount);
				String title = "Session Tracking Example";
				arg1.setContentType("text/html");
				PrintWriter out= arg1.getWriter();
				Enumeration attList = sess.getAttributeNames();
				StringBuffer al= new StringBuffer(40);
				while(attList.hasMoreElements())
					al.append((String)attList.nextElement()+":");
				out.println(ServletUtilities.headWithTitle(title)+
						"<BODY BGCOLOR=\"#FDF5E6\">"+
						"<H1 ALIGN=\"CENTER\">"+sessionHead+"</H1><BR>"+
						"<H2>Information on your session:</H2>"+
						"<TABLE BORDER=1 ALIGN=\"CENTER\">"+
						"<TR BGCOLOR=\"#FFAD00\">"+
						"  <TH>Info Type<TH>Value"+
						"<TR>"+
						//"<TR>"+
						"  <TD>ID"+
						"  <TD>"+sess.getId()+
						"<TR>"+
						"  <TD>Creation Time"+
						"  <TD>"+ new Date(sess.getCreationTime())+
						"<TR>"+
						"  <TD>Time of Last Access"+
						"  <TD>"+ new Date(sess.getLastAccessedTime())+
						"<TR>"+
						"  <TD>List of Attributes this session have"+
						"  <TD>"+ al+
						"<TR>"+
						"  <TD>Number of Previous Access"+
						"  <TD>"+ accessCount +
						"</TABLE></BODY></HTML>"
				);
			}

		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}	
	}
