import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class GettingHref extends HttpServlet
	{	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{ 	HttpSession sess = arg0.getSession();
				String sessId = sess.getId();
				String atrbId = (String) sess.getAttribute("sessionID");
				String message = (sessId.equalsIgnoreCase(atrbId)?"Matched":"Not matched");
				arg1.setContentType("text/html");
				PrintWriter out = arg1.getWriter();
				
				out.println(ServletUtilities.headWithTitle("Getting session through href")+
						"<BODY BGCOLOR=\"#FDF5E6\">"+
						"<H1 ALIGN=\"CENTER\">"+"Session Tracking using Link."+"</H1>"+
						
						"<BODY BGCOLOR=\"#FDF5E6\">"+
						"<H1 ALIGN=\"CENTER\">Session Tracking through href</H1><BR><BR>"+
						"<H3 ALIGN=\"CENTER\">"+message+"</H1>"+
						"</BODY></HTML>"
				);
				
			}

		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	}	
	}