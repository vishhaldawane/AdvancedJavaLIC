import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UsingHref extends HttpServlet
	{	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	HttpSession sess = arg0.getSession(true);
				Integer accessCount = (Integer) sess.getAttribute("accesscount");
				String accessHead;
				if (accessCount == null)
					{	accessCount = new Integer(0);
						accessHead = "Well Come New Commer";
					}
				else
					accessHead = "Well Come Old User";
				accessCount = new Integer(accessCount.intValue()+1);
				sess.setAttribute("accesscount", accessCount);
				
				sess.setAttribute("sessionID", sess.getId());
				arg1.setContentType("text/html");
				PrintWriter out = arg1.getWriter();
				out.println(ServletUtilities.headWithTitle("Sesstion Tracking using Link.")+
						"<BODY BGCOLOR=\"#FDF5E6\">"+
						"<H1 ALIGN=\"CENTER\">"+"Session Tracking using Link."+"</H1>"+
						"The session ID of this session is : <BR>"+sess.getId()+"<BR><BR>"+
						"<A HREF=\"/SessionTracking122/gettinghref\">"+
						"<CENTER>"+
						"<CODE>Go to gettingHREF</CODE>"+
						"</CENTER>"+
						"</BODY></HTML>"
						);
				
			}

		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}	
	}
