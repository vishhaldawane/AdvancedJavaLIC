/* Prior to this program, run PasswordBuilder.java which accepts passwords and create
 * a properties file Password at PassWord file at MyServlet/RequestHeader/WEB-INF/src
 *  
 * this program is reading this file as a property file to get a list of authentic users.
 * Reading request header to get a user trying to log now
 * If this user is present in the list of authentic header, he is asked to login
 * otherwise again prompted to log.
 * 
 * Features of program
 * ***** How to read property file
 * ***** How to convert BYTE64 encription into original string.
 * ***** How to set status to SC-UNAUTHORIZED and set response header to Authentication.
 */
package packlogin02;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sun.misc.BASE64Decoder;

public class PasswordServlet extends HttpServlet
	{	SavingBankBean sbb;
		public void init(ServletConfig config) throws ServletException
			{	super.init(config);
				ServletContext sct = config.getServletContext();
				
				String driver = sct.getInitParameter("drv");
				String url    = sct.getInitParameter("url");
				
				String user   = config.getInitParameter("user");
				String pass   = config.getInitParameter("pass");
				try
					{	sbb = new SavingBankBean(driver, url, user, pass);	}
				catch(Exception e)
					{	throw new ServletException("Unable to open connection", e);	}
			}
		
		protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	arg1.setContentType("text/html");
				PrintWriter out = arg1.getWriter();
				System.out.println("----------------------");
				String authorize = arg0.getHeader("Authorization");
				if (authorize== null)
					{	System.out.println("Did not get Authorization header");
						askForPassword(arg1);	}
				else
					{	String userInfo = authorize.substring(6).trim();// Basic scott:tiger
						BASE64Decoder decoder = new BASE64Decoder();
						String nameAndPassword = new String(decoder.decodeBuffer(userInfo));
						int index = nameAndPassword.indexOf(":");
						String user = nameAndPassword.substring(0, index);
						String password = nameAndPassword.substring(index+1);
						System.out.println(user+":"+password);
						
						String realPassword=null;
						try {	realPassword = sbb.findNameOnNumber(Integer.parseInt(user));	}
						catch (NumberFormatException e)
							{	new ServletException("Parsing Problem with Account Number", e);	}
						catch (SQLException e)
							{	new ServletException("Connection Problem with DataBase", e);	 }
						
						if ((realPassword != null) && (realPassword.equalsIgnoreCase(password)))
							{	
								System.out.println("true");
								String title = "Welcome Mr. "+password;	
								out.print(title);
							}
						else
							{	
							System.out.println("false");
							askForPassword(arg1);	}
					}
			}
		
		private void askForPassword(HttpServletResponse arg1)
			{	System.out.println("Asking for password.");
				arg1.setStatus(arg1.SC_UNAUTHORIZED);
				arg1.setHeader("WWW-Authenticate", "BASIC realm=\"privileged-few\"");
			}
		
		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}
	}
