package packlogin02;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class SavingBankBean
	{	Connection conn;
			
		public SavingBankBean(String driver, String url, String user, String passwd) throws ClassNotFoundException, SQLException
			{	Class.forName(driver);
				System.out.println(" D:"+driver+" U:"+url+" N:"+user+" P"+passwd);
				conn = DriverManager.getConnection(url, user, passwd);
			}
		
		public String findNameOnNumber(int accNo) throws SQLException
			{	String query = "Select accNm from AccountMaster where accNo=?";
				PreparedStatement st = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				
				st.setInt(1, accNo);
				ResultSet rs = st.executeQuery();
				String accNm=null;
				if (rs.next())
					accNm = rs.getString("AccNm");
				
				rs.close();
				st.close();
				return accNm;
			}
		
		public void closeAll() throws SQLException
			{	conn.close();	}
		
		public static void main(String [] argv)
			{	String driver = "oracle.jdbc.driver.OracleDriver";
				String url ="jdbc:oracle:thin:@rac940:1521:CHANDRA";
				
				String userName = "scott";
				String passWd = "tiger";
				try {	SavingBankBean sbb = new SavingBankBean(driver, url, userName, passWd);
						
						String nm = sbb.findNameOnNumber(1);
						System.out.println("nm : "+nm);
						
						sbb.closeAll();
					}
				catch (ClassNotFoundException e)
					{	e.printStackTrace();	}
				catch (SQLException e)
					{	e.printStackTrace();	}
			}
	}
