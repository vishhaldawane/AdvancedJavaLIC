/* This program is reading a pdf file and putting on the browser.
 * For this purpose, program is taking servlet context of the current servlet
 * Getting resourceStream from the servlet context and 
 * reading data from the resource and directing it to output steam of servlet response.
 */
package packgeneinform;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ReadPDF extends HttpServlet
	{	protected void doGet(HttpServletRequest req, HttpServletResponse res)
    		throws ServletException, IOException
    		{	res.setContentType("application/pdf");	// Setting content type.
    		
		        ServletContext context = getServletContext();
		        ServletConfig config = getServletConfig();
			    String filePath = config.getInitParameter("filepath");
			    String fileName = config.getInitParameter("filename");
			    
			    InputStream is = context.getResourceAsStream(File.separator+filePath+File.separator+fileName);
		        //InputStream is = context.getResourceAsStream("/WEB-INF/GeneralFiles/Chapter 8 Handling Cookies.pdf");
	
		        int read = 0;
		        byte bytes[] = new byte[1024];
		        OutputStream os = res.getOutputStream();
		        while((read = is.read(bytes))!= -1)
		        	{os.write(bytes, 0, read);}
		        os.flush();
		        os.close();
		    }
	}

