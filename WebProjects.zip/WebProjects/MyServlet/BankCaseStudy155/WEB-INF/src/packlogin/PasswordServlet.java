/* Prior to this program, run PasswordBuilder.java which accepts passwords and create
 * a properties file Password at PassWord file at MyServlet/RequestHeader/WEB-INF/src
 *  
 * this program is reading this file as a property file to get a list of authentic users.
 * Reading request header to get a user trying to log now
 * If this user is present in the list of authentic header, he is asked to login
 * otherwise again prompted to log.
 * 
 * Features of program
 * ***** How to read property file
 * ***** How to convert BYTE64 encription into original string.
 * ***** How to set status to SC-UNAUTHORIZED and set response header to Authentication.
 */
package packlogin;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sun.misc.BASE64Decoder;

public class PasswordServlet extends HttpServlet
	{	private Properties passwords;
		private String passwordFile;
		public void init(ServletConfig config) throws ServletException
			{	super.init(config);
				try
					{	passwordFile = config.getInitParameter("passwordFile");
						passwords = new Properties();
						passwords.load(new FileInputStream(passwordFile));
					}
				catch(IOException ioe)
					{}
			}
		protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	arg1.setContentType("text/html");
				PrintWriter out = arg1.getWriter();
				System.out.println("----------------------");
				String authorize = arg0.getHeader("Authorization");
				if (authorize== null)
					{	System.out.println("Did not get Author. header");
						askForPassword(arg1);	}
				else
					{	String userInfo = authorize.substring(6).trim();// Basic oracle:tiger
						BASE64Decoder decoder = new BASE64Decoder();
						String nameAndPassword = new String(decoder.decodeBuffer(userInfo));
						int index = nameAndPassword.indexOf(":");
						String user = nameAndPassword.substring(0, index);
						String password = nameAndPassword.substring(index+1);
						System.out.println(user+":"+password);
						String realPassword = passwords.getProperty(user);
						
						if ((realPassword != null) && (realPassword.equalsIgnoreCase(password)))
							{	System.out.println("true");
								String title = "Welcome Mr. "+user;
								HttpSession sess = arg0.getSession(true);
								sess.setAttribute("cc", sess.getId());
								out.print(title);
								out.print("<FORM ACTION=\"http://localhost:7001/BankCaseStudy155/accoptions\" METHOD=\"POST\">");
								out.print("<CENTER>");
									out.print("<SELECT NAME=\"accounttype\" VALUE=\"1\">");
										out.print("<OPTION VALUE = \"current\">Current</OPTION>");
										out.print("<OPTION VALUE = \"saving\">Saving</OPTION>");
									out.print("</SELECT>");
									out.print("<INPUT TYPE = \"SUBMIT\" NAME = \"submit\" VALUE = \"SUBMIT\">");
							out.print("</CENTER>");
							out.print("</BODY> </HTML>");
							}
						else
							{	System.out.println("false");
								askForPassword(arg1);
							}
					}
			}
		private void askForPassword(HttpServletResponse arg1)
			{	System.out.println("Asking for password.");
				arg1.setStatus(arg1.SC_UNAUTHORIZED);
				arg1.setHeader("WWW-Authenticate", "BASIC realm=\"privileged-few\"");
			}
		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}
	}
