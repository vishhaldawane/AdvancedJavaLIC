package packlogin;
import java.io.FileOutputStream;
import java.util.Properties;

// This application writes a simple java properties file
// containing usernames and associated passwords.
// Observe, the file is being created at the given path.
// The file is not stored in encripted form.
// This password file is read by a servlet PasswordServlet.java to perform password security.
//
public class PasswordBuilder
	{	public static void main(String[] args) throws Exception
			{ 	Properties passwords = new Properties();
				passwords.put("a", "aa");
				passwords.put("b", "bb");
				passwords.put("c", "cc");
				passwords.put("d", "dd");
				String passWordFile="C:\\D. Chandra\\Java\\D.Chandra New\\MyServlet\\RequestResponse66\\WEB-INF\\src\\Password\\PassWords";
				FileOutputStream out = new FileOutputStream(passWordFile);
				
				passwords.store(out, "PassWord"); // The second parameter is a String Header which goes at the top of a file
			}

}
