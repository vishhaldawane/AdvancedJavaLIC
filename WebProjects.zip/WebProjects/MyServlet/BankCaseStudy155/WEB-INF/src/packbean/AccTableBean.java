package packbean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class AccTableBean
	{	Connection con;
		Statement st;
		PreparedStatement pst;
		ResultSet rs;
		public AccTableBean() throws NamingException, SQLException
			{	Context cst = new InitialContext();
				DataSource ds = (DataSource)cst.lookup("ThinJNDI");
				con = ds.getConnection();
				st = con.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
			}
		
		public AccBean isExist(int accNo) throws SQLException
			{	rs = st.executeQuery("select EMPNO, ENAME, SAL from emp where EMPNO="+accNo);
				AccBean eb = new AccBean();
				while (rs.next())
					{	eb.setAccNo(rs.getInt(1));
						eb.setAccNm(rs.getString(2));
						eb.setAccBal(rs.getFloat(3));
						return eb;
					}
				return null;
			}
		
		public boolean addNew(AccBean eb) throws SQLException
			{	AccBean ebb = isExist(eb.getAccNo());
				if (ebb != null)
					return false;
				pst = con.prepareStatement("insert into emp (EMPNO, ENAME, SAL) values (?,?, ?)");
				pst.setInt(1, eb.getAccNo());
				pst.setString(2, eb.getAccNm());
				pst.setFloat(3, eb.getAccBal());
				
				pst.executeUpdate();
				
				/*	rs = st.executeQuery("SELECT EMPNONO, ENAME, SAL FROM EMP");
					rs.moveToInsertRow();
					rs.updateInt(1, eb.getAccNo());
					rs.updateString(2,eb.getAccNm());
					rs.updateString(3, eb.getAccBal());
					rs.insertRow();
					rs.close();
				*/
				con.close();
				return true;
			}
		
		public boolean deleteOld(int accNo)  throws SQLException
			{	AccBean eb = isExist(accNo);
				if (eb==null)
					return false;
				pst = con.prepareStatement("Delete from emp where empno = ?");
				pst.setInt(1, accNo);
				pst.executeUpdate();
				con.close();
				return true;
			}
		public Object[] getList() throws SQLException
			{	
				rs = st.executeQuery("select EMPNO, ENAME, SAL from emp");
				LinkedList ll = new LinkedList();
				//AccBean[] eb = new AccBean[20];
				AccBean e;
				
				while(rs.next())
					{	e = new AccBean();
						e.setAccNo(rs.getInt(1));
						e.setAccNm(rs.getString(2));
						e.setAccBal(rs.getFloat(3));
						System.out.print(e.getAccNo()+" "+e.getAccNm()+" "+e.getAccBal());
						ll.add(e);
					}
				con.close();
				return ll.toArray();
				
			}
	}
