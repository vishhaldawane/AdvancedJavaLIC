package packbean;

public class TransferBean extends AccBean
	{	
		boolean isAccNo = true;
		boolean isAccNm = true;
		boolean isAccBal = true;
		
		public TransferBean()
			{	super();	}

		public boolean isAccBal()
			{	return isAccBal;	}

		public void setIsAccBal(boolean isAccBal)
			{	this.isAccBal = isAccBal;	}

		public boolean isAccNm()
			{	return isAccNm;	}

		public void setIsAccNm(boolean isAccNm)
			{	this.isAccNm = isAccNm;	}

		public boolean isAccNo()
			{	return isAccNo;	}

		public void setIsAccNo(boolean isAccNo)
			{	this.isAccNo = isAccNo;	}
	}
