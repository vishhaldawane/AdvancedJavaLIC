package packbean;

public class AccBean
	{	int accNo=1;
		String accNm=" ";
		float accBal=0.0f;
		
		public AccBean()
			{}

		public float getAccBal()
			{	return accBal;	}

		public void setAccBal(float accBal)
			{	this.accBal = accBal;	}

		public String getAccNm()
			{	return accNm;	}

		public void setAccNm(String accNm)
			{	this.accNm = accNm;	}

		public int getAccNo()
			{	return accNo;	}

		public void setAccNo(int accNo)
			{	this.accNo = accNo;	}
	}
