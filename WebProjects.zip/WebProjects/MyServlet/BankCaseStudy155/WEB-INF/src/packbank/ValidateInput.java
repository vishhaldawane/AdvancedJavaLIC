package packbank;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import packbean.AccBean;
import packbean.AccTableBean;
import packbean.TransferBean;

public class ValidateInput extends HttpServlet
	{	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	HttpSession sess = arg0.getSession(false);
				TransferBean accb = (TransferBean) sess.getAttribute("TRANSFERBEAN");
				accb.setAccNo(ServletUtilities.getIntParameter(arg0, "formAccNo", 0));
				accb.setAccNm(ServletUtilities.getStringParameter(arg0, "formAccNm", ""));
				accb.setAccBal(ServletUtilities.getFloatParameter(arg0, "formAccBal", 0.0f));
				PrintWriter out = arg1.getWriter();
				arg1.setContentType("text/html");
				
				boolean toGoForward = true;
				// Validation
				if (accb.getAccNo()== 0)
					{	accb.setIsAccNo(false);
						toGoForward = false;
					}
				else
					accb.setIsAccNo(true);
				
				if ((accb.getAccNm()== null)||(accb.getAccNm().trim().equalsIgnoreCase("")))
					{	accb.setIsAccNm(false);
						toGoForward = false;
					}
				else
					accb.setIsAccNm(true);
				
				if (accb.getAccBal()== 0)
					{	accb.setIsAccBal(false);
						toGoForward = false;
					}
				else
					accb.setIsAccBal(true);
				
				RequestDispatcher rd = null;
				
				if (toGoForward)
					{	AccTableBean abt = (AccTableBean)sess.getAttribute("ACCTABLEBEAN");
						
						try {	abt.addNew((AccBean) accb);
								//rd = arg0.getRequestDispatcher("/currentservlet");
								//rd.forward(arg0, arg1);
							}
						catch (SQLException e)
							{	
								e.printStackTrace();	}
					}
				else
					{	sess.setAttribute("TRANSFERBEAN", accb);
						rd = arg0.getRequestDispatcher("/currinput");
						rd.forward(arg0, arg1);
					}
			}
	}
