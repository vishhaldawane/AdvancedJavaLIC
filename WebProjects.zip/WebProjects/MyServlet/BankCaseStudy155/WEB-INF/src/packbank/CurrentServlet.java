package packbank;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CurrentServlet extends HttpServlet
	{	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	String acctype = arg0.getParameter("accounttype");
				HttpSession sess = arg0.getSession();
				String sessid = sess.getId();
				String sessatr = (String) sess.getAttribute("sessionID");
				String sessmtch = (sessid.equalsIgnoreCase(sessatr)?"Session Matched":"Session unmatched");
				arg1.setContentType("text/html");
				PrintWriter out = arg1.getWriter();
				out.println(ServletUtilities.headWithTitle("CurrentServlet")+
						"<BODY BGCOLOR=\"#FDF4E6\">" +
						"<H3 ALIGN=\"CENTER\">Current Servlet</H3><BR>");
				out.print("<FORM ACTION=\"http://localhost:7001/BankCaseStudy155/currcontrol\" METHOD=\"POST\">");	
				out.print("<SELECT NAME=\"operationtype\" VALUE=\"1\">");
					out.print("<OPTION VALUE = \"lst\">List all Account Holders</OPTION>");
					out.print("<OPTION VALUE = \"add\">Add new Account Holder</OPTION>");
					out.print("<OPTION VALUE = \"del\">Delete old Account Holder</OPTION>");
				out.print("</SELECT>");
				out.print("<INPUT TYPE = \"SUBMIT\" NAME = \"submit\" VALUE = \"SUBMIT\">");
						
				out.print("</BODY></HTML>");
			}

		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}	
	}
