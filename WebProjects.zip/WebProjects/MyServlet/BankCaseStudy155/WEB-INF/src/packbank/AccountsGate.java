package packbank;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AccountsGate extends HttpServlet
	{	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	String accounttype = arg0.getParameter("accounttype");
				if (accounttype==null)
					accounttype="Current";
				HttpSession sess = arg0.getSession(false);
				if (sess == null)
				String sessId = sess.getId();
				String sid = sess.getAttribute("cc");
				if (!sessId.equals(sid))
					{	RequestDispatcher rd = arg0.getRequestDispatcher("/passwd");
						rd.forward(arg0, arg1);
					}
				arg1.setContentType("text/html");
				PrintWriter out = arg1.getWriter();
				out.println(ServletUtilities.headWithTitle("CurrentServlet")+
						"<BODY BGCOLOR=\"#FDF4E6\">" +
						"<H3 ALIGN=\"CENTER\">Bank Servlet</H3><BR>"+
						"<H4 ALIGN=\"CENTER\">XYZ BANK</H4><BR><BR>"+
						"<H5 ALIGN=\"CENTER\">Branch Mumbai</H5>"+
						"</BODY></HTML>"
						);
				
				RequestDispatcher rd;
				if (accounttype.equalsIgnoreCase("Current"))
					{	rd = arg0.getRequestDispatcher("/currentservlet");
						rd.forward(arg0, arg1);
					}
				else
					{	rd = arg0.getRequestDispatcher("/savingservlet");
						rd.include(arg0, arg1);
					}
				out.close();
			}

		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);}
	}
