package packbank;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import packbean.AccBean;
import packbean.AccTableBean;
import packbean.TransferBean;

public class CurrentControl extends HttpServlet
	{	public void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	arg1.setContentType("text/html");
				PrintWriter out = arg1.getWriter();
				String oper = arg0.getParameter("operationtype");
				HttpSession sess = arg0.getSession();
				AccBean eb = null;
				try {	AccTableBean etb = new AccTableBean();
						sess.setAttribute("ACCTABLEBEAN", etb);
						if (oper.equalsIgnoreCase("add"))
							{	TransferBean accb = new TransferBean();
								sess.setAttribute("TRANSFERBEAN", accb);
								RequestDispatcher rd = arg0.getRequestDispatcher("/currinput");
								rd.forward(arg0, arg1);
							}
						else if (oper.equalsIgnoreCase("lst"))
							{	Object[] obj = etb.getList();
								for(int i=0; i<obj.length; i++)
									{	eb = (AccBean) obj[i];
										out.print(eb.getAccNo()+" "+eb.getAccNm()+" "+eb.getAccBal()+"<BR>");
									}
							}
						else if (oper.equalsIgnoreCase("del"))
							{	RequestDispatcher rd = arg0.getRequestDispatcher("/currinput");
								rd.forward(arg0, arg1);
							}
					}
				catch (NamingException e)
					{	e.printStackTrace();	}
				catch (SQLException e)
					{	e.printStackTrace();	}
				catch (ServletException e)
					{	e.printStackTrace();	}
				catch (IOException e)
					{	e.printStackTrace();	}
			}
	
		public void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}
	}
