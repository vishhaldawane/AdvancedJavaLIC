package packbank;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import packbean.TransferBean;

public class CurrentInput extends HttpServlet
	{	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	HttpSession sess = arg0.getSession();
				String str = (String) sess.getAttribute("sessionID");
				TransferBean accb = (TransferBean) sess.getAttribute("TRANSFERBEAN");
				PrintWriter out = arg1.getWriter();
				arg1.setContentType("text/html");
				out.println(ServletUtilities.headWithTitle("XYZ Overseas Bank"));
				out.println("<BODY BGCOLOR=\"#FDF5E6\">");
				out.println("<H1 ALIGN=\"CENTER\">Add New Current Account</H1>");
				out.println("<FORM ACTION = \"http://localhost:7001/BankCaseStudy155/validate\" METHOD = \"POST\">");
				out.println("<TABLE ALIGN=\"center\" WIDTH=\"100%\" cellspacing=\'2\' cellpadding=\'2\' >");
				//<font color="red"><b>*</b></font>
				
				if (accb.isAccNo())
					out.println("<font color=\"black\"><b>*</b></font>");
				else
					out.println("<font color=\"red\"><b>*</b></font>");
				out.println("<B>Account Number : </B>");
				out.println("&nbsp;<INPUT TYPE=\"TEXT\" NAME = \"formAccNo\" VALUE=\'"+accb.getAccNo()+"\'><BR>");
				
				if (accb.isAccNm())
					out.println("<font color=\"black\"><b>*</b></font>");
				else
					out.println("<font color=\"red\"><b>*</b></font>");
				out.println("<B>Account Hrld Name : </B>      <INPUT TYPE=\"TEXT\" NAME = \"formAccNm\" VALUE=\'"+accb.getAccNm()+"\'><BR>");
				
				if (accb.isAccBal())
					out.println("<font color=\"black\"><b>*</b></font>");
				else
					out.println("<font color=\"red\"><b>*</b></font>");
				
				out.println("<B>Account Balance : </B>&nbsp;<INPUT TYPE=\"TEXT\" NAME = \"formAccBal\" VALUE=\'"+accb.getAccBal()+"\'><BR>");
				
					out.println("<BR><BR>");
					out.println("<CENTER>");
						out.println("<INPUT TYPE=\"RESET\" VALUE = \"RESET\">");
						out.println("<INPUT TYPE=\"SUBMIT\" NAME=\"submit\" VALUE = \"SUBMIT\">");
					out.println("</CENTER>");
				out.println("</TABLe>");
				out.println("</FORM>");
				out.println("</BODY>");
				out.println("</HTML>");
				/*
				<BODY BGCOLOR="#FDF5E6">
				<H1 ALIGN="CENTER">Collecting Three Parameters</H1>
				<FORM ACTION = "http://localhost:7001/CollectParameters22/param" METHOD = "POST">
				<TABLE ALIGN="center" WIDTH="100%" cellspacing='2' cellpadding='2' >
			<!Text boxes and label>
					<B>First Parameter : </B>&nbsp;<INPUT TYPE="TEXT" NAME = "param1" VALUE="AAAA"><BR>
					<B>Second Parameter: </B>      <INPUT TYPE="TEXT" NAME = "param2"><BR>
					<B>Third Parameter : </B>&nbsp;<INPUT TYPE="PASSWORD" NAME = "param3"><BR>
			<!Combo Box>
					<BR><BR>		
					<B>Color:</B>
						<Select name="color" size="1">
							<option value="Red">Red</option>
							<option value="Green">Green</option>
							<option value="Blue">Blue</option>
						</Select>
			<!Radio Buttons>
					<BR><BR>
					<H3>Marital Status:</H3>
						Married<INPUT TYPE="RADIO" NAME="marital" VALUE="MARRIED"><BR>
						Unmarried<INPUT TYPE="RADIO" NAME="marital" VALUE="UNMARRIED"><BR>
						Widowed<INPUT TYPE="RADIO" NAME="marital" VALUE="WIDOWED"><BR>
					<BR><BR>
			<!Text Area>
					<B>Address:</B>
					<Textarea name='problem' cols="50" rows="4"></textarea>
			<!Check Boxes>
					<BR><BR>
					<H3>News paper you read:</H3>
						Times of India<INPUT TYPE="CHECKBOX" NAME="news" VALUE="Times of India"<BR>
						Hitwad        <INPUT TYPE="CHECKBOX" NAME="news" VALUE="Hitwad"<BR>
						Lokmat        <INPUT TYPE="CHECKBOX" NAME="news" VALUE="Lokmat"<BR>
					<BR><BR>
					<CENTER>
						<INPUT TYPE="RESET" VALUE = "RESET">
						<INPUT TYPE="SUBMIT" NAME="submit" VALUE = "SUBMIT">
					</CENTER>
					</TABLe>
				</FORM>
			</BODY>
		</HTML>*/
			}

		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}
	}
