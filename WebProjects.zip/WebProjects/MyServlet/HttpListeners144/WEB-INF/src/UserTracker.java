import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class UserTracker implements HttpSessionListener
	{	public static int users=0;
		public void sessionCreated(HttpSessionEvent arg0)
			{	users++;
				HttpSession sess = arg0.getSession();
				String str = sess.getId();
				System.out.println("Session Created. : "+str.substring(str.length()-5));
			}

		public void sessionDestroyed(HttpSessionEvent arg0)
			{	users--;
				HttpSession sess = arg0.getSession();
				String str = sess.getId();
				System.out.println("Session destroyed. : "+str.substring(str.length()-5));
			}
		
		public static int getUsers()
			{	return users;	}
	}
