import javax.servlet.http.HttpSessionAttributeListener;import javax.servlet.http.HttpSessionBindingEvent;
;
public class SessionAttributeListener implements HttpSessionAttributeListener
	{	public void attributeAdded(HttpSessionBindingEvent arg0)
			{	
				System.out.println("");
		
			}

	public void attributeRemoved(HttpSessionBindingEvent arg0)
		{	}

	public void attributeReplaced(HttpSessionBindingEvent arg0)
		{	}	

	}
