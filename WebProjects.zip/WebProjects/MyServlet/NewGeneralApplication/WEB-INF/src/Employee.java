
public class Employee
	{	int empNo;
		String empNm;
		
		public Employee()
			{	}

		public int getEmpNo()
			{	return empNo;	}

		public void setEmpNo(int empId)
			{	this.empNo = empId;	}

		public String getEmpNm()
			{	return empNm;	}

		public void setEmpNm(String empNm)
			{	this.empNm = empNm;	}
		
		public String toString()
			{	return "Number : "+empNo+" Name : "+empNm;	}
		
		public static void main(String [] argv)
			{	Employee e = new Employee();
				e.setEmpNo(101);
				e.setEmpNm("Ramesh");
				
				System.out.println(e);
				System.out.println("Emp Id:"+e.getEmpNo()+" Name:"+e.getEmpNm());
			}
	}
