import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EntryServlet extends HttpServlet 
	{	Connection con;
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@rac940:1521:CHANDRA";
		String user = "scott";
		String pass = "tiger";
		
		public void init() throws ServletException
			{	super.init();
				ServletContext sct = getServletContext();
				ServletConfig sc = getServletConfig();
				driver = sct.getInitParameter("driver");
				url = sct.getInitParameter("url");
				user = sc.getInitParameter("user");
				pass = sc.getInitParameter("pass");
				
				try {
					Class.forName(driver);
					con = DriverManager.getConnection(url, user, pass);
					}
				catch(ClassNotFoundException cnf)
					{	System.out.println("Class not found in init.");	}
				catch(SQLException sq)
					{	System.out.println("SQLException in init.");	}	
			}
		
		protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException 
			{	int empNo=0;
				String empNm= null;
				PrintWriter out = arg1.getWriter();
				arg1.setContentType("text/plain");
				try {
						empNo = Integer.parseInt(arg0.getParameter("empNo"));
						empNm = arg0.getParameter("empNm");
					}
				catch (NumberFormatException e1)
					{	e1.printStackTrace(out);	}
				
				EmpMasterTable em = new EmpMasterTable(con);
				
				Employee e = new Employee();
				e.setEmpNo(empNo);
				e.setEmpNm(empNm);
				try	{	em.addNew(e);
						out.println("Record added successfully.");
				}
				catch(SQLException sq)
					{	out.println("Error in writing to back end.");	}
			}
	
		protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException
			{	doGet(arg0, arg1);	}	
	}
