import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EmpMasterTable
	{	Connection con;
		Statement st;
		ResultSet rs;
		
		public EmpMasterTable(Connection con)
			{	try	{	this.con = con;		
						st = con.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
					}
				
				catch(SQLException se)
					{	System.out.println("Connection not opened.");}
			}

		public boolean isEmpExist(int empNo)
			{	try 	{	rs = st.executeQuery("SELECT EMPID FROM EMPMASTER WHERE EMPID="+empNo);
							
							if (rs.next())
								{	return true;	}
						}
				catch(SQLException se)
					{	System.out.println("Query Execution failed.");}
				return false;
			}
		
		public void addNew(Employee e) throws SQLException
			{	PreparedStatement pst = con.prepareStatement("INSERT INTO EMPMASTER (EMPID, EMPNAME) VALUES (?, ?)");
			
				pst.setInt(1, e.getEmpNo());
				pst.setString(2, e.getEmpNm());
				
				pst.executeUpdate();
				
				System.out.println("Record Added:"+e);
			}
		
		public static void main(String [] argv)
			{	String driver ="oracle.jdbc.driver.OracleDriver";
				String url = "jdbc:oracle:thin:@rac940:1521:CHANDRA";
				
				try {
				Class.forName(driver);
				Connection con = DriverManager.getConnection(url, "scott", "tiger");
				
				EmpMasterTable emt = new EmpMasterTable(con);
				
				if (emt.isEmpExist(101))
					System.out.println("101 exist.");
				else
					System.out.println("Something wrong.");
				if (!emt.isEmpExist(106))
					System.out.println("106 does not exist.");
				else
					System.out.println("Something wrong.");
				}
				catch ( ClassNotFoundException cnf)
					{	System.out.println("Add external jar Classes12.jar in eclipse.");}
				catch (SQLException sq)
					{	System.out.println("Unable to open connection.");	}
			}
	}